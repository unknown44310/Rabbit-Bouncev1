extends Area2D

func _on_collision_shape_2d_child_entered_tree(node: Node) -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
